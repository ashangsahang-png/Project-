import * as THREE from 'three';
import { GLTFLoader } from './vendor/loaders/GLTFLoader.js';

/* ---------- Renderer / scene ---------- */
const canvas = document.querySelector('#scene');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.6));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.15;

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x0b101c);
scene.fog = new THREE.Fog(0x0b101c, 18, 70);
const camera = new THREE.PerspectiveCamera(55, window.innerWidth / window.innerHeight, 0.1, 250);
let yaw = 0.65, pitch = 0.28, distance = 6.5;
const target = new THREE.Vector3(0, 1, 0);
function updateCamera() {
  camera.position.set(
    target.x + distance * Math.sin(yaw) * Math.cos(pitch),
    target.y + distance * Math.sin(pitch),
    target.z + distance * Math.cos(yaw) * Math.cos(pitch)
  );
  camera.lookAt(target);
}
updateCamera();

scene.add(new THREE.HemisphereLight(0xc7e6ff, 0x252b3b, 2.1));
const keyLight = new THREE.DirectionalLight(0xffffff, 2.3); keyLight.position.set(4, 9, 5); scene.add(keyLight);
const fill = new THREE.PointLight(0x4f9dff, 22, 18); fill.position.set(-4, 4, -3); scene.add(fill);

const floorMat = new THREE.MeshStandardMaterial({ color: 0x20283a, roughness: .85, metalness: .08 });
const floor = new THREE.Mesh(new THREE.PlaneGeometry(200, 200), floorMat); floor.rotation.x = -Math.PI / 2; floor.position.y = -.025; scene.add(floor);
const grid = new THREE.GridHelper(100, 100, 0x3c6683, 0x26384d); grid.position.y = 0.005; scene.add(grid);
const ring = new THREE.Mesh(new THREE.RingGeometry(1.05, 1.08, 64), new THREE.MeshBasicMaterial({ color: 0x49cfff, side: THREE.DoubleSide }));
ring.rotation.x = -Math.PI / 2; ring.position.y = .015; scene.add(ring);

/* ---------- World (studio / open world) ---------- */
const world = new THREE.Group(); scene.add(world);
let worldMode = 'studio';
function disposeObject(root) {
  root.traverse(n => {
    n.geometry?.dispose?.();
    if (n.material) for (const m of (Array.isArray(n.material) ? n.material : [n.material])) m.dispose?.();
  });
}
function setWorld(mode) {
  worldMode = mode;
  for (const obj of [...world.children]) { world.remove(obj); disposeObject(obj); }
  if (mode === 'open') {
    scene.background = new THREE.Color(0x9bc8d9); scene.fog = new THREE.Fog(0x9bc8d9, 28, 100);
    floor.material.color.set(0x344b3d); grid.visible = false; ring.visible = false;
    const sun = new THREE.DirectionalLight(0xffe5b5, 2.0); sun.position.set(-15, 25, 12); world.add(sun);
    for (let i = 0; i < 38; i++) {
      const x = (Math.random() - .5) * 48, z = (Math.random() - .5) * 48;
      if (Math.abs(x) < 4 && Math.abs(z) < 4) continue;
      const trunk = new THREE.Mesh(new THREE.CylinderGeometry(.12, .18, 1.5, 7), new THREE.MeshStandardMaterial({ color: 0x5e4030 }));
      trunk.position.set(x, .75, z); world.add(trunk);
      const leaves = new THREE.Mesh(new THREE.ConeGeometry(.85, 2.2, 8), new THREE.MeshStandardMaterial({ color: 0x2c7147 }));
      leaves.position.set(x, 2.4, z); world.add(leaves);
    }
  } else {
    scene.background = new THREE.Color(0x0b101c); scene.fog = new THREE.Fog(0x0b101c, 18, 70);
    floor.material.color.set(0x20283a); grid.visible = true; ring.visible = true;
  }
  document.querySelector('#worldBtn').textContent = mode === 'studio' ? 'STUDIO ▾' : 'OPEN WORLD ▾';
  document.querySelector('#studioBtn').classList.toggle('active', mode === 'studio');
}
setWorld('studio');

/* ---------- UI helpers ---------- */
const empty = document.querySelector('#empty'), panel = document.querySelector('#modelPanel'), select = document.querySelector('#modelSelect');
const status = document.querySelector('#status');
function toast(msg) {
  const el = document.querySelector('#toast');
  el.textContent = msg; el.style.display = 'block';
  clearTimeout(toast.timer); toast.timer = setTimeout(() => el.style.display = 'none', 3500);
}
function setStatus(msg) { status.textContent = msg; }

/* ---------- Loader (optional Draco / Meshopt support) ---------- */
let dracoLoader = null, meshopt = null;
const decoderReady = (async () => {
  try {
    const { DRACOLoader } = await import('./vendor/loaders/DRACOLoader.js');
    dracoLoader = new DRACOLoader().setDecoderPath('./vendor/draco/gltf/');
  } catch (e) { console.warn('Draco tidak tersedia', e); }
  try {
    const m = await import('./vendor/libs/meshopt_decoder.module.js');
    meshopt = m.MeshoptDecoder;
  } catch (e) { console.warn('Meshopt tidak tersedia', e); }
})();

const baseName = p => decodeURIComponent(String(p)).split(/[\\/]/).pop().toLowerCase();

/** resources: Map<lowercase basename, Blob|File> untuk .bin / tekstur milik .gltf */
function parseGltf(data, resources) {
  const manager = new THREE.LoadingManager();
  const made = [];
  if (resources && resources.size) {
    manager.setURLModifier(url => {
      if (/^(data:|blob:|https?:)/i.test(url)) return url;
      const blob = resources.get(baseName(url));
      if (!blob) return url;
      const u = URL.createObjectURL(blob); made.push(u); return u;
    });
  }
  const loader = new GLTFLoader(manager);
  if (dracoLoader) loader.setDRACOLoader(dracoLoader);
  if (meshopt) loader.setMeshoptDecoder(meshopt);
  return new Promise((resolve, reject) => loader.parse(data, '', resolve, reject))
    .finally(() => setTimeout(() => made.forEach(u => URL.revokeObjectURL(u)), 10000));
}

/* ---------- Models ---------- */
// entry: { name, holder (Group yang digerakkan), model (hasil GLTF), mixer, clips:{idle,walk,run}, currentClip, currentAction }
const models = [];
let active = null;
let runMode = false, jumpTime = 0;

function fitModel(model) {
  model.updateWorldMatrix(true, true);
  const box = new THREE.Box3().setFromObject(model);
  const size = box.getSize(new THREE.Vector3());
  const max = Math.max(size.x, size.y, size.z);
  if (!Number.isFinite(max) || max <= 0) throw new Error('Ukuran model tidak valid');
  // 1) skala dulu, 2) baru hitung ulang box lalu pusatkan & letakkan di lantai
  model.scale.multiplyScalar(2.5 / max);
  model.updateWorldMatrix(true, true);
  box.setFromObject(model);
  const c = box.getCenter(new THREE.Vector3());
  model.position.x -= c.x; model.position.z -= c.z; model.position.y -= box.min.y;
}

function pickClips(animations) {
  if (!animations.length) return null;
  const find = re => animations.find(c => re.test(c.name));
  const idle = find(/idle|stand|breath|wait|diam/i) || animations[0];
  const others = animations.filter(c => c !== idle);
  const walk = find(/walk|jalan/i) || find(/move|locomotion/i) || (animations.length === 2 ? others[0] : idle);
  const run = find(/run|sprint|jog|lari/i) || walk;
  const jump = find(/jump|lompat|hop/i) || null;
  const crouch = find(/crouch|squat|duck|kneel|jongkok/i) || null;
  return { idle, walk, run, jump, crouch };
}

/** Putar klip. once=true: sekali lalu berhenti (mis. lompat), selain itu berulang. */
function playClip(entry, clip, once = false) {
  if (!entry.mixer || !clip) return;
  if (entry.currentClip === clip && !once) return;
  const next = entry.mixer.clipAction(clip);
  next.reset(); next.enabled = true; next.setEffectiveWeight(1);
  if (once) { next.setLoop(THREE.LoopOnce, 1); next.clampWhenFinished = true; }
  else { next.setLoop(THREE.LoopRepeat, Infinity); next.clampWhenFinished = false; }
  next.play();
  if (entry.currentAction && entry.currentAction !== next) entry.currentAction.crossFadeTo(next, .2, true);
  entry.currentClip = clip; entry.currentAction = next;
}

/** Aksi manual dari panel AKSI / tombol: menimpa animasi jalan/diam sampai selesai atau dihentikan. */
function playAction(entry, clip, loop) {
  if (!entry || !entry.mixer || !clip) return;
  entry.action = { clip, loop };
  playClip(entry, clip, !loop);
}
function stopAction(entry) {
  if (!entry) return;
  entry.action = null; entry.currentClip = null; entry.crouchOn = false;
  crouchBtn.classList.remove('active');
}

const actionPanel = document.querySelector('#actionPanel'), actionList = document.querySelector('#actionList');
const loopChk = document.querySelector('#loopChk'), crouchBtn = document.querySelector('#crouchBtn');
function buildActionList(entry) {
  actionList.innerHTML = '';
  if (!entry || !entry.animations.length) {
    const d = document.createElement('div'); d.className = 'none';
    d.textContent = 'Model ini tidak punya animasi bawaan.'; actionList.append(d); return;
  }
  entry.animations.forEach((clip, i) => {
    const b = document.createElement('button');
    b.textContent = clip.name || `Animasi ${i + 1}`;
    b.addEventListener('click', () => {
      entry.crouchOn = false; crouchBtn.classList.remove('active');
      playAction(entry, clip, loopChk.checked);
    });
    actionList.append(b);
  });
}

function activate(entry) {
  if (active) scene.remove(active.holder);
  active = entry;
  scene.add(entry.holder);
  target.set(entry.holder.position.x, 1, entry.holder.position.z);
  crouchBtn.classList.toggle('active', !!entry.crouchOn);
  buildActionList(entry);
  if (entry.mixer && !entry.action) playClip(entry, entry.clips.idle);
}

async function addModel(name, data, resources) {
  await decoderReady;
  const gltf = await parseGltf(data, resources);
  const holder = new THREE.Group();
  holder.add(gltf.scene);
  fitModel(gltf.scene);
  const entry = { name, holder, model: gltf.scene, animations: gltf.animations || [], mixer: null, clips: null, currentClip: null, currentAction: null, action: null, crouchOn: false };
  if (entry.animations.length) {
    entry.mixer = new THREE.AnimationMixer(gltf.scene);
    entry.clips = pickClips(entry.animations);
    // aksi sekali-putar selesai -> kembali ke animasi jalan/diam
    entry.mixer.addEventListener('finished', e => {
      if (entry.action && !entry.action.loop && e.action === entry.currentAction) { entry.action = null; entry.currentClip = null; }
    });
  }
  models.push(entry);
  activate(entry);
  refreshSelect(models.length - 1);
  empty.classList.add('hidden'); panel.classList.remove('hidden');
  setStatus(`${name} · siap digunakan`);
  distance = 5.5; updateCamera();
  toast(gltf.animations?.length ? `${name} dimuat · ${gltf.animations.length} animasi` : `${name} dimuat · tanpa animasi bawaan`);
}

function refreshSelect(index) {
  select.innerHTML = '';
  models.forEach((m, i) => { const o = document.createElement('option'); o.value = String(i); o.textContent = m.name; select.append(o); });
  select.value = String(index);
}
select.addEventListener('change', () => {
  const entry = models[Number(select.value)];
  if (!entry) return;
  activate(entry);
  setStatus(`${entry.name} · model aktif`);
});

/* ---------- Import ---------- */
const MODEL_EXT = ['glb', 'gltf'];
const extOf = n => n.toLowerCase().split('.').pop();

async function readZip(file) {
  let zip;
  try { zip = await window.JSZip.loadAsync(file); }
  catch (err) { console.error(err); toast('ZIP tidak dapat dibuka. Coba ZIP yang valid.'); return 0; }
  // abaikan sampah macOS (__MACOSX/._xxx.glb) dan folder
  const names = Object.keys(zip.files).filter(n => !zip.files[n].dir && !n.startsWith('__MACOSX/') && !baseName(n).startsWith('._'));
  const modelNames = names.filter(n => MODEL_EXT.includes(extOf(n)));
  if (!modelNames.length) { toast('ZIP tidak berisi file .glb / .gltf.'); return 0; }
  let resources = null;
  if (modelNames.some(n => extOf(n) === 'gltf')) {
    resources = new Map();
    for (const n of names) if (!MODEL_EXT.includes(extOf(n))) resources.set(baseName(n), await zip.files[n].async('blob'));
  }
  let ok = 0;
  for (const n of modelNames) {
    const short = n.split('/').pop();
    try {
      const data = extOf(n) === 'gltf' ? await zip.files[n].async('string') : await zip.files[n].async('arraybuffer');
      await addModel(short, data, resources); ok++;
    } catch (err) { console.error(err); toast(`Gagal memuat ${short}`); }
  }
  return ok;
}

async function handleFiles(fileList) {
  const files = [...fileList];
  // semua file non-model yang dipilih bersamaan (.bin, .png, .jpg) dipakai sebagai resource .gltf
  const resources = new Map();
  for (const f of files) if (!MODEL_EXT.includes(extOf(f.name)) && extOf(f.name) !== 'zip') resources.set(baseName(f.name), f);
  let loaded = 0;
  for (const file of files) {
    const ext = extOf(file.name);
    try {
      if (ext === 'zip') loaded += await readZip(file);
      else if (ext === 'glb') { await addModel(file.name, await file.arrayBuffer()); loaded++; }
      else if (ext === 'gltf') { await addModel(file.name, await file.text(), resources); loaded++; }
      else if (!files.some(f => extOf(f.name) === 'gltf')) toast(`Format .${ext} belum didukung. Gunakan GLB.`);
    } catch (err) {
      console.error(err);
      toast(`Gagal memuat ${file.name}. Pastikan file valid (GLB/GLTF).`);
    }
  }
  if (!loaded && files.length && !models.length) setStatus('Pilih file .glb untuk memuat karakter');
}
const fileInput = document.querySelector('#fileInput');
function chooseFiles() { fileInput.value = ''; fileInput.click(); }
document.querySelector('#importBtn').addEventListener('click', chooseFiles);
document.querySelector('#anotherBtn').addEventListener('click', chooseFiles);
document.querySelector('#importBottom').addEventListener('click', chooseFiles);
fileInput.addEventListener('change', e => handleFiles(e.target.files));

/* ---------- Buttons ---------- */
document.querySelector('#worldBtn').addEventListener('click', () => setWorld(worldMode === 'studio' ? 'open' : 'studio'));
document.querySelector('#studioBtn').addEventListener('click', () => setWorld('studio'));
document.querySelector('#upBtn').addEventListener('click', () => { distance = Math.max(1.8, distance - .7); updateCamera(); });
document.querySelector('#downBtn').addEventListener('click', () => { distance = Math.min(20, distance + .7); updateCamera(); });
document.querySelector('#resetBtn').addEventListener('click', () => { yaw = .65; pitch = .28; distance = 6.5; target.set(active ? active.holder.position.x : 0, 1, active ? active.holder.position.z : 0); updateCamera(); });
document.querySelector('#runBtn').addEventListener('click', () => {
  runMode = !runMode;
  document.querySelector('#runBtn').classList.toggle('active', runMode);
  toast(runMode ? 'Mode lari dipilih' : 'Mode jalan dipilih');
});
document.querySelector('#jumpBtn').addEventListener('click', () => {
  if (!active) { toast('Impor model terlebih dahulu'); return; }
  if (jumpTime <= 0) jumpTime = .45;
  if (active.clips?.jump) { active.crouchOn = false; crouchBtn.classList.remove('active'); playAction(active, active.clips.jump, false); }
});
crouchBtn.addEventListener('click', () => {
  if (!active) { toast('Impor model terlebih dahulu'); return; }
  active.crouchOn = !active.crouchOn;
  crouchBtn.classList.toggle('active', active.crouchOn);
  if (active.clips?.crouch) {
    if (active.crouchOn) playAction(active, active.clips.crouch, true);
    else { active.action = null; active.currentClip = null; }
  }
});
document.querySelector('#actionBtn').addEventListener('click', e => {
  const open = actionPanel.classList.toggle('hidden') === false;
  e.currentTarget.classList.toggle('active', open);
});
document.querySelector('#stopAct').addEventListener('click', () => stopAction(active));

/* ---------- Joystick ---------- */
let moveX = 0, moveY = 0;
const joy = document.querySelector('#joystick'), stick = document.querySelector('#stick');
function joyMove(e) {
  const r = joy.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height / 2;
  let dx = e.clientX - cx, dy = e.clientY - cy; const max = 31, len = Math.hypot(dx, dy) || 1;
  if (len > max) { dx = dx / len * max; dy = dy / len * max; }
  stick.style.transform = `translate(${dx}px,${dy}px)`; moveX = dx / max; moveY = dy / max;
}
joy.addEventListener('pointerdown', e => { joy.setPointerCapture(e.pointerId); joyMove(e); });
joy.addEventListener('pointermove', e => { if (joy.hasPointerCapture(e.pointerId)) joyMove(e); });
function joyEnd() { moveX = moveY = 0; stick.style.transform = 'translate(0,0)'; }
joy.addEventListener('pointerup', joyEnd); joy.addEventListener('pointercancel', joyEnd); joy.addEventListener('lostpointercapture', joyEnd);

/* ---------- Camera drag ---------- */
let dragging = false, lastX = 0, lastY = 0;
canvas.addEventListener('pointerdown', e => { dragging = true; lastX = e.clientX; lastY = e.clientY; canvas.setPointerCapture(e.pointerId); });
canvas.addEventListener('pointermove', e => {
  if (!dragging) return;
  const dx = e.clientX - lastX, dy = e.clientY - lastY; lastX = e.clientX; lastY = e.clientY;
  yaw -= dx * .008; pitch = Math.max(-.15, Math.min(1.25, pitch - dy * .006)); updateCamera();
});
canvas.addEventListener('pointerup', () => dragging = false); canvas.addEventListener('pointercancel', () => dragging = false);

/* ---------- Main loop ---------- */
const TWO_PI = Math.PI * 2;
const clock = new THREE.Clock();
let wasMoving = false;
const fwd = new THREE.Vector3(), rgt = new THREE.Vector3(), dir = new THREE.Vector3();
function animate() {
  requestAnimationFrame(animate);
  const dt = Math.min(clock.getDelta(), .05);
  if (active) {
    const moving = Math.abs(moveX) > .03 || Math.abs(moveY) > .03;
    const h = active.holder;
    // mulai berjalan -> hentikan aksi berulang / jongkok (aksi sekali-putar seperti lompat tetap selesai)
    if (moving && !wasMoving && (active.crouchOn || (active.action && active.action.loop))) stopAction(active);
    wasMoving = moving;
    // jongkok tanpa klip bawaan: pipihkan model
    const squash = active.crouchOn && !active.clips?.crouch ? .72 : 1;
    h.scale.y += (squash - h.scale.y) * Math.min(1, dt * 12);
    if (moving) {
      const speed = runMode ? 4.2 : 2.1;
      fwd.set(-Math.sin(yaw), 0, -Math.cos(yaw)); rgt.set(Math.cos(yaw), 0, -Math.sin(yaw));
      dir.set(0, 0, 0).addScaledVector(fwd, -moveY).addScaledVector(rgt, moveX);
      h.position.addScaledVector(dir, speed * dt);
      // hadapkan karakter ke arah jalan (model glTF menghadap +Z)
      const want = Math.atan2(dir.x, dir.z);
      const diff = ((want - h.rotation.y + Math.PI) % TWO_PI + TWO_PI) % TWO_PI - Math.PI;
      h.rotation.y += diff * Math.min(1, dt * 12);
      target.x = h.position.x; target.z = h.position.z;
    }
    if (jumpTime > 0) {
      jumpTime = Math.max(0, jumpTime - dt);
      h.position.y = jumpTime > 0 ? Math.sin((.45 - jumpTime) / .45 * Math.PI) * .8 : 0;
    }
    if (active.mixer) {
      const c = active.clips;
      if (!active.action) playClip(active, moving ? (runMode ? c.run : c.walk) : c.idle);
      active.mixer.update(dt);
    }
  }
  updateCamera(); renderer.render(scene, camera);
}
animate();
window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight; camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});
